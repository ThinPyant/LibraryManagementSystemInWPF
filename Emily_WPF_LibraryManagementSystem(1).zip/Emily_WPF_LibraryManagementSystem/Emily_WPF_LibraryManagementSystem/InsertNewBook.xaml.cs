﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Data;
using System.Windows.Documents;
using System.Windows.Input;
using System.Windows.Media;
using System.Windows.Media.Imaging;
using System.Windows.Navigation;
using System.Windows.Shapes;
using System.Data.OleDb;
using System.Data;

namespace Emily_WPF_LibraryManagementSystem
{
    /// <summary>
    /// Interaction logic for InsertNewBook.xaml
    /// </summary>
    public partial class InsertNewBook : Page
    {
        OleDbConnection con;
        int bookID = 0;

        public InsertNewBook()
        {
            InitializeComponent();
        }

        private void BtnInsert_Click(object sender, RoutedEventArgs e)
        {
            if (con.State == ConnectionState.Closed)
                con.Open();

            try
            {
                bookID = Convert.ToInt32(txtBookID.Text);
                string title = txtTitle.Text;
                string author = txtAuthor.Text;
                string genre = txtGenre.Text;
                int borrow = Convert.ToInt32(txtBorrow.Text);
                int bookCount = Convert.ToInt32(txtBookCount.Text);
                int total = Convert.ToInt32(txtQuantity.Text);

                string queryString = "insert into BookList Values (@bookID,@title,@author,@genre,@borrow,@bookCount,@total)";
                OleDbCommand cmd = new OleDbCommand(queryString, con);
                cmd.Parameters.AddWithValue("@BookID", bookID);
                cmd.Parameters.AddWithValue("@Title", title);
                cmd.Parameters.AddWithValue("@Author", author);
                cmd.Parameters.AddWithValue("@Genre", genre);
                cmd.Parameters.AddWithValue("@BorrowCount", borrow);
                cmd.Parameters.AddWithValue("@BookCount", bookCount);
                cmd.Parameters.AddWithValue("@TotalQuantity", total);

                cmd.ExecuteNonQuery();
                con.Close();
                MessageBox.Show("Successfully inserted");
            }
            catch
            {
                MessageBox.Show("Please fill all information!!!");
            }
        }

        private void BtnCancel_Click(object sender, RoutedEventArgs e)
        {
            AdminHome adminHome = new AdminHome();
            this.NavigationService.Navigate(adminHome);
        }

        private void BtnBack_Click(object sender, RoutedEventArgs e)
        {
            AdminHome adminHome = new AdminHome();
            this.NavigationService.Navigate(adminHome);
        }

        private void Page_Loaded(object sender, RoutedEventArgs e)
        {
            string bookID = "";
            con = new OleDbConnection();
            con.ConnectionString = @"Provider=Microsoft.Jet.OLEDB.4.0;Data Source=Library.mdb";
            con.Open();

            OleDbCommand cmd1 = new OleDbCommand();
            cmd1.CommandText = "SELECT TOP 1 BookID FROM BookList ORDER BY BookID DESC";
            cmd1.Connection = con;

            OleDbDataReader reader = cmd1.ExecuteReader();

            while (reader.Read())
            {
                bookID = reader["BookID"].ToString();
            }

            bookID = (Convert.ToInt32(bookID) + 1).ToString();
            txtBookID.Text = bookID.ToString();
        }
    }
}
