﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Data;
using System.Windows.Documents;
using System.Windows.Input;
using System.Windows.Media;
using System.Windows.Media.Imaging;
using System.Windows.Navigation;
using System.Windows.Shapes;
using System.Data.OleDb;
using System.Data;

namespace Emily_WPF_LibraryManagementSystem
{
    /// <summary>
    /// Interaction logic for Issue.xaml
    /// </summary>
    public partial class Issue : Page
    {
        OleDbCommand cmd;
        OleDbConnection con;
        bool state = true;
        int selectedID = 0;
        int count = 0;
        int borrow = 0;
        int bookCount = 0;
        int total = 0;
        int j = 0;

        public Issue()
        {
            InitializeComponent();
        }

        private void BtnIssue_Click(object sender, RoutedEventArgs e)
        {
            if (con.State == ConnectionState.Closed)
                con.Open();

            int issueID = 0;
            string name = "";
            string title = txtTitle.Text;
            int userid = Convert.ToInt32(txtUserID.Text);
            selectedID = Convert.ToInt32(txtID.Text);

            //UserID section
            OleDbCommand cmd1 = new OleDbCommand();
            cmd1 = con.CreateCommand();
            cmd1.CommandType = CommandType.Text;
            cmd1.CommandText = "select * from Login where UserID= @userid";
            cmd1.Parameters.AddWithValue("UserID", @userid);
            cmd1.ExecuteNonQuery();
            OleDbDataAdapter adapter = new OleDbDataAdapter(cmd1);
            DataTable table1 = new DataTable();
            adapter.Fill(table1);
            int i = table1.Rows.Count;

            if (i == 0)
            {
                MessageBox.Show("User can not be found!!!");
                state = false;
            }
            else
            {
                foreach (DataRow row in table1.Rows)
                {
                    //txtUserID.Text = row["UserID"].ToString();
                    name = row["UserName"].ToString();
                }
            }

            //Issue Process
            if (state == true)
            {
                //Check if 2 books issued
                cmd = new OleDbCommand("select * from issue where IssuedUserID = @userid", con);
                cmd.Parameters.AddWithValue("@IssuedUserID", userid);//added
                OleDbDataAdapter oda = new OleDbDataAdapter(cmd);
                DataTable table = new DataTable();
                oda.Fill(table);
                int rows = table.Rows.Count;

                if (rows >= 2)
                {
                    MessageBox.Show("Cannot issue more books.\nA user can only issue 2 books.");
                    state = false;
                }
                
                //check book count != 0
                try
                {
                    if (state == true)
                    {
                        cmd = new OleDbCommand("select * from BookList where BookID =@selectedID", con);
                        cmd.Parameters.AddWithValue("@BookID", selectedID);
                        OleDbDataReader reader1 = cmd.ExecuteReader();
                        if (reader1.Read())
                        {
                            bookCount = Convert.ToInt32(reader1["BookCount"].ToString());
                        }

                        if (bookCount == 0)
                        {
                            MessageBox.Show(bookCount .ToString (),"bookCount");
                            MessageBox.Show("Desired book is not available!!!");
                        }
                        else
                        {
                            OleDbCommand cmd3 = new OleDbCommand();
                            cmd3 = con.CreateCommand();
                            cmd3.CommandType = CommandType.Text;
                            cmd3.CommandText = "select Top 1 ID from Issue order by ID DESC";
                            OleDbDataReader reader = cmd3.ExecuteReader();

                            while (reader.Read())
                            {
                                issueID = Convert.ToInt32(reader["ID"].ToString());
                            }
                           
                            issueID = issueID + 1;

                            DateTime startDate = (DateTime)issuedDate.SelectedDate;
                            DateTime endDate = startDate.AddDays(7);
                            string start = startDate.ToShortDateString();
                            string end = endDate.ToShortDateString();

                            OleDbCommand cmd2 = new OleDbCommand();
                            cmd2 = con.CreateCommand();
                            cmd2.CommandType = CommandType.Text;
                            cmd2.CommandText = "Insert Into Issue Values (@issueID,@userid,@name,@selectedID,@title,@start,@end)";
                            cmd2.Parameters.AddWithValue("@ID", issueID);
                            cmd2.Parameters.AddWithValue("@IssuedUserID", userid);
                            cmd2.Parameters.AddWithValue("@IssuedUserName", name);
                            cmd2.Parameters.AddWithValue("@IssuedBookID", selectedID);
                            cmd2.Parameters.AddWithValue("@IssuedBookTitle", title);
                            cmd2.Parameters.AddWithValue("@IssuedDate", start);
                            cmd2.Parameters.AddWithValue("@EndDate", end);

                            j = cmd2.ExecuteNonQuery();

                            con.Close();
                            MessageBox.Show("Successfully Issued.");
                            Clear();
                            updateBookList();
                        }
                    }

                }
                catch (Exception ex)
                {
                    MessageBox.Show(ex.Message);
                }
            }
        }

        private void Clear()
        {
            txtID.Text = "";
            txtTitle.Text = "";
            txtAuthor.Text = "";
            txtGenre.Text = "";
            txtBorrow.Text = "";
            txtBookCount.Text = "";
            txtTotal.Text = "";
            txtUserID.Text = "";
        }

        private void Page_Loaded(object sender, RoutedEventArgs e)
        {
            con = new OleDbConnection();
            con.ConnectionString = @"Provider=Microsoft.Jet.OLEDB.4.0;Data Source=Library.mdb";
            con.Open();
            display();
        }

        public void display()
        {
            cmd = new OleDbCommand("select *  from BookList order by BookID ASC", con);
            OleDbDataAdapter adapter = new OleDbDataAdapter(cmd);
            DataTable table = new DataTable();
            adapter.Fill(table);
            dataGrid.ItemsSource = table.DefaultView;
        }

        private void updateBookList()
        {
            if (j == 1)
            {
                if (state == true)
                {
                    con.Open();
                    
                    cmd = new OleDbCommand("select * from BookList where BookID=@selectedID ", con);
                    cmd.Parameters.AddWithValue("@BookID", selectedID);
                    OleDbDataAdapter adapter = new OleDbDataAdapter(cmd);
                    DataTable dt = new DataTable();
                    adapter.Fill(dt);

                    foreach (DataRow row in dt.Rows)
                    {
                        borrow = Convert.ToInt32(row["BorrowCount"].ToString());
                        bookCount = Convert.ToInt32(row["BookCOunt"].ToString());
                        total = Convert.ToInt32(row["TotalQuantity"].ToString());
                    }

                    if (bookCount != 0)
                    {
                        borrow = borrow + 1;
                        bookCount = total - borrow;
                        total = borrow + bookCount;
                        cmd = new OleDbCommand("Update BookList set BorrowCount =@borrow, BookCount =@bookCount, TotalQuantity=@total where BookID=@selectedID", con);
                        cmd.Parameters.AddWithValue("@BorrowCount", borrow);
                        cmd.Parameters.AddWithValue("@BookCount", bookCount);
                        cmd.Parameters.AddWithValue("@TotalQuantity", total);
                        cmd.Parameters.AddWithValue("@BookID", selectedID);
                        cmd.ExecuteNonQuery();
                    }
                    else
                    {
                        state = false;
                        MessageBox.Show("Desired books are not available.");
                    }
                }
            }
        }

        private void Button_Click(object sender, RoutedEventArgs e)
        {
            AdminHome  adminHome = new AdminHome ();
            this.NavigationService.Navigate(adminHome );
        }

        private void DataGrid_SelectionChanged(object sender, SelectionChangedEventArgs e)
        {
            DataGrid gd = (DataGrid)sender;
            DataRowView row_selected = gd.SelectedItem as DataRowView;

            if (row_selected != null)
            {
                txtID.Text = row_selected["BookID"].ToString();
                txtTitle.Text = row_selected["Title"].ToString();
                txtAuthor.Text = row_selected["Author"].ToString();
                txtGenre.Text = row_selected["Genre"].ToString();
                txtBorrow.Text = row_selected["BorrowCount"].ToString();
                txtBookCount.Text = row_selected["BookCount"].ToString();
                txtTotal.Text = row_selected["TotalQuantity"].ToString();
            }

            selectedID = Convert.ToInt32(txtID.Text);
        }
    }
}
