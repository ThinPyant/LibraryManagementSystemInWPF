﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Data;
using System.Windows.Documents;
using System.Windows.Input;
using System.Windows.Media;
using System.Windows.Media.Imaging;
using System.Windows.Navigation;
using System.Windows.Shapes;
using System.Data.OleDb;
using System.Data;

namespace Emily_WPF_LibraryManagementSystem
{
    /// <summary>
    /// Interaction logic for UserRegisteration.xaml
    /// </summary>
    public partial class UserRegisteration : Page
    {
        OleDbConnection con;
        string userid;

        public UserRegisteration()
        {
            InitializeComponent();
        }

        private void BtnSignUp_Click(object sender, RoutedEventArgs e)
        {
            if (con.State == ConnectionState.Closed)
                con.Open();

            string name = txtName.Text;
            string pass = txtPassword.Password;
            string passRetype = txtRetype.Password;
            int permission = 2;
            if (pass.Length == 6)
            {
                if (pass != passRetype)
                {
                    MessageBox.Show("Password Mismatch!! Try Again");
                }
                else
                {
                    if (name != "")
                    {
                        OleDbCommand cmd = new OleDbCommand();
                        cmd.CommandText = "INSERT INTO Login VALUES (@userid,@name,@pass, @permission)";
                        cmd.Parameters.AddWithValue("@UserID", userid);
                        cmd.Parameters.AddWithValue("@Username", name);
                        cmd.Parameters.AddWithValue("@Password", pass);
                        cmd.Parameters.AddWithValue("@Permission ", permission);
                        cmd.Connection = con;
                        int result = cmd.ExecuteNonQuery();

                        if (result == 1)
                        {
                            MessageBox.Show("Successfully SignUp");
                            Login login = new Login();
                            this.NavigationService.Navigate(login);
                            Login.userid = userid;
                        }
                    }
                    else
                    {
                        MessageBox.Show("Please fill all information!!!");
                    }
                }
            }
            else
            {
                MessageBox.Show("Password must be 6 characters.");
            }
        }

        private void Page_Loaded(object sender, RoutedEventArgs e)
        {
            con = new OleDbConnection();
            con.ConnectionString = @"Provider=Microsoft.Jet.OLEDB.4.0;Data Source=Library.mdb";
            con.Open();

            OleDbCommand cmd1 = new OleDbCommand();
            cmd1.CommandText = "SELECT TOP 1 UserID FROM Login ORDER BY UserID DESC";
            cmd1.Connection = con;

            OleDbDataReader reader = cmd1.ExecuteReader();

            while (reader.Read())
            {
                userid = reader["UserID"].ToString();
            }

            userid = (Convert.ToInt32(userid) + 1).ToString();
            Login.userid = userid;
        }
    }
}
