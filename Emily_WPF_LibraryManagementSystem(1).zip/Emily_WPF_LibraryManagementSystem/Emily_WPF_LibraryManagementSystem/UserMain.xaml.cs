﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Data;
using System.Windows.Documents;
using System.Windows.Input;
using System.Windows.Media;
using System.Windows.Media.Imaging;
using System.Windows.Navigation;
using System.Windows.Shapes;
using System.Data.OleDb;
using System.Data;

namespace Emily_WPF_LibraryManagementSystem
{
    /// <summary>
    /// Interaction logic for UserMain.xaml
    /// </summary>
    public partial class UserMain : Page
    {
        OleDbConnection con;
        DataTable table = new DataTable();

        public UserMain()
        {
            InitializeComponent();
        }
        
        private void BtnSearch_Click(object sender, RoutedEventArgs e)
        {
            if (con.State == ConnectionState.Closed)
                con.Open();

            OleDbCommand cmd = new OleDbCommand("SELECT * FROM BookList" +
                " WHERE (Title LIKE '" + txtSearch.Text + "%')  " +
                "OR (Author LIKE '" + txtSearch.Text + " % ')", con);
            OleDbDataAdapter adapterSearch = new OleDbDataAdapter(cmd);
            DataTable table1 = new DataTable();
            adapterSearch.Fill(table1);
            dataGrid.ItemsSource = table1.AsDataView();
        }

        private void Page_Loaded(object sender, RoutedEventArgs e)
        {
            con = new OleDbConnection();
            con.ConnectionString = @"Provider=Microsoft.Jet.OLEDB.4.0;Data Source=Library.mdb";
            displayBooks();
        }

        private void displayBooks()
        {
            OleDbCommand cmd = new OleDbCommand("Select BookID,Title,Author,Genre,BookCount from BookList order by BookID ASC", con);
            OleDbDataAdapter adapter = new OleDbDataAdapter(cmd);
            DataTable table = new DataTable();
            adapter.Fill(table);
            dataGrid.ItemsSource = table.AsDataView();
        }
        
        private void BtnLogout_Click(object sender, RoutedEventArgs e)
        {
            Login login = new Login();
            this.NavigationService.Navigate(login);
        }
    }
}