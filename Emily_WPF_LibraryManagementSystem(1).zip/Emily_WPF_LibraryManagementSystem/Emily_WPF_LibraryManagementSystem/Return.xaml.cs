﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Data;
using System.Windows.Documents;
using System.Windows.Input;
using System.Windows.Media;
using System.Windows.Media.Imaging;
using System.Windows.Navigation;
using System.Windows.Shapes;
using System.Data.OleDb;
using System.Data;

namespace Emily_WPF_LibraryManagementSystem
{
    /// <summary>
    /// Interaction logic for Return.xaml
    /// </summary>
    public partial class Return : Page
    {
        OleDbConnection con;
        int selectedID = 0;
        string userID = "";
        string userName = "";
        string bookID = "";
        string bookTitle = "";
        string start = "";
        string end = "";

        public Return()
        {
            InitializeComponent();
        }

        private void BtnReturn_Click(object sender, RoutedEventArgs e)
        {
            if (con.State == ConnectionState.Closed)
                con.Open();

            OleDbCommand cmd = new OleDbCommand("delete * from Issue where ID =@selectedID", con);
            cmd.Parameters.AddWithValue("@ID", selectedID);
            cmd.ExecuteNonQuery();
            MessageBox.Show("Successfully Returned");
            display();
            Clear();
        }

        private void Clear()
        {
            txtID.Text = "";
            txtUserID.Text = "";
            txtUserName.Text = "";
            txtBookID.Text = "";
            txtBookTitle.Text = "";
            txtStartDate.Text = "";
            txtEndDate.Text = "";
        }

        private void Page_Loaded(object sender, RoutedEventArgs e)
        {
            con = new OleDbConnection();
            con.ConnectionString = @"Provider=Microsoft.Jet.OLEDB.4.0;Data Source=Library.mdb";

            display();
        }

        private void display()
        {
            OleDbCommand cmd = new OleDbCommand("select * from Issue order by ID ASC", con);
            OleDbDataAdapter adapter = new OleDbDataAdapter(cmd);
            DataTable table = new DataTable();
            adapter.Fill(table);
            dataGrid.ItemsSource = table.DefaultView;
        }

        private void BtnBack_Click(object sender, RoutedEventArgs e)
        {
            AdminHome adminHome = new AdminHome();
            this.NavigationService.Navigate(adminHome);
        }

        private void DataGrid_SelectionChanged(object sender, SelectionChangedEventArgs e)
        {
            DataGrid gd = (DataGrid)sender;
            DataRowView row_selected = gd.SelectedItem as DataRowView;

            if (row_selected != null)
            {
                txtID.Text = row_selected["ID"].ToString();
                txtUserID.Text = row_selected["IssuedUserID"].ToString();
                txtUserName.Text = row_selected["IssuedUserName"].ToString();
                txtBookID.Text = row_selected["IssuedBookID"].ToString();
                txtBookTitle.Text = row_selected["IssuedBookTitle"].ToString();
                txtStartDate.Text = row_selected["StartDate"].ToString();
                txtEndDate.Text = row_selected["EndDate"].ToString();
            }

            selectedID = Convert.ToInt32(txtID.Text);
            userID = txtUserID.Text;
            userName = txtUserName.Text;
            bookID = txtBookID.Text;
            bookTitle = txtBookTitle.Text;
            start = txtStartDate.Text;
            end = txtEndDate.Text;
        }
    }
}
