﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Data;
using System.Windows.Documents;
using System.Windows.Input;
using System.Windows.Media;
using System.Windows.Media.Imaging;
using System.Windows.Navigation;
using System.Windows.Shapes;
using System.Data.OleDb;
using System.Data;
using System.Windows.Controls.Primitives;

namespace Emily_WPF_LibraryManagementSystem
{
    /// <summary>
    /// Interaction logic for EditBooks.xaml
    /// </summary>
    public partial class EditBooks : Page
    {
        OleDbCommand cmd;
        OleDbConnection con;
        int selectedID;
        string title = "";
        string author = "";
        string genres = "";
        int borrow = 0;
        int bookCount = 0;
        int total = 0;
        bool state = true;

        public EditBooks()
        {
            InitializeComponent();
        }

        private void Page_Loaded(object sender, RoutedEventArgs e)
        {
            con = new OleDbConnection();
            con.ConnectionString = @"Provider=Microsoft.Jet.OLEDB.4.0;Data Source=Library.mdb;";
            con.Open();

            displayBooks();

            OleDbCommand cmd1 = new OleDbCommand();
            cmd1.CommandText = "SELECT TOP 1 BookID FROM BookList ORDER BY BookID DESC";
            cmd1.Connection = con;

            OleDbDataReader reader = cmd1.ExecuteReader();

            while (reader.Read())
            {
                selectedID = Convert.ToInt32(reader["BookID"].ToString());
            }
        }

        private void displayBooks()
        {
            OleDbCommand cmd = new OleDbCommand("Select * from BookList order by BookID ASC", con);
            OleDbDataAdapter adapter = new OleDbDataAdapter(cmd);
            DataTable table = new DataTable();
            adapter.Fill(table);
            dataGrid.ItemsSource = table.DefaultView;
        }

        private void DataGrid_SelectionChanged(object sender, SelectionChangedEventArgs e)
        {
            DataGrid gd = (DataGrid)sender;
            DataRowView row_selected = gd.SelectedItem as DataRowView;

            if (row_selected != null)
            {
                txtID.Text = row_selected["BookID"].ToString();
                txtTitle.Text = row_selected["Title"].ToString();
                txtAuthor.Text = row_selected["Author"].ToString();
                txtGenre.Text = row_selected["Genre"].ToString();
                txtBorrow.Text = row_selected["BorrowCount"].ToString();
                txtBookCount.Text = row_selected["BookCount"].ToString();
                txtTotal.Text = row_selected["TotalQuantity"].ToString();
            }

            selectedID = Convert.ToInt32(txtID.Text);
            title = txtTitle.Text;
            author = txtAuthor.Text;
            genres = txtGenre.Text;
            borrow = Convert.ToInt32(txtBorrow.Text);
            bookCount = Convert.ToInt32(txtBookCount.Text);
            total = Convert.ToInt32(txtTotal.Text);
        }


        private void BtnUpdate_Click(object sender, RoutedEventArgs e)
        {
            if (con.State == ConnectionState.Closed)
            {
                con.Open();
            }

            if (state == true)
            {
                try
                {
                    cmd = new OleDbCommand("update BookList set Title = '" + txtTitle.Text + "', BorrowCount = '" + txtBorrow.Text + "', BookCount = '" + txtBookCount.Text + "',TotalQuantity = '" + txtTotal.Text + "' where BookID=selectedID ", con);
                    cmd.Parameters.AddWithValue("@BookID", selectedID);
                    cmd.Parameters.AddWithValue("@Title", title); cmd.Parameters.AddWithValue("@BorrowCount", borrow);
                    cmd.Parameters.AddWithValue("@BookCount", bookCount);
                    cmd.Parameters.AddWithValue("@BorrowCount", borrow);
                    cmd.Parameters.AddWithValue("@TotalQuantity", total);
                    cmd.ExecuteNonQuery();
                    int result = cmd.ExecuteNonQuery();

                    if (result == 1)
                    {
                        MessageBox.Show("Successfully updated.");
                        Clear();
                    }

                    displayBooks();
                }
                catch
                {
                    //MessageBox.Show("Hey! There is already a book with this BookID.\nBookID's have to be distinct.");

                }
            }
            else
            {
                MessageBox.Show("There is already a book with this BookID.\nBookID's have to be distinct.");
            }

        }

        private void BtnSearch_Click(object sender, RoutedEventArgs e)
        {
            if (con.State == ConnectionState.Closed)
                con.Open();

            OleDbCommand cmd = new OleDbCommand("SELECT * FROM BookList WHERE Title LIKE '" + txtSearch.Text + "%' Author LIKE '" + txtSearch.Text + "%'", con);
            OleDbDataAdapter adapterSearch = new OleDbDataAdapter(cmd);
            DataTable table = new DataTable();
            adapterSearch.Fill(table);

            dataGrid.ItemsSource = table.DefaultView;
        }

        private void Clear()
        {
            txtID.Text = "";
            txtTitle.Text = "";
            txtAuthor.Text = "";
            txtGenre.Text = "";
            txtBorrow.Text = "";
            txtBookCount.Text = "";
            txtTotal.Text = "";
        }

        private void BtnClear_Click(object sender, RoutedEventArgs e)
        {
            Clear();
        }

        private void BtnDelete_Click(object sender, RoutedEventArgs e)
        {
            state = true;

            if (con.State == ConnectionState.Closed)
                con.Open();

            if (state == true)
            {
                try
                {
                    cmd = new OleDbCommand("select IssuedBookID from Issue where IssuedBookID=@selectedID", con);
                    cmd.Parameters.AddWithValue("@IssuedBookID", selectedID);
                    OleDbDataReader read = cmd.ExecuteReader();

                    if (read.Read())
                    {
                        MessageBox.Show("Cannot delete an issued book.\nPlease make sure the book is not issued to a student before deleting it.");
                    }
                    else
                    {
                        cmd = new OleDbCommand("delete from BookList where BookID = @selectedID", con);
                        cmd.Parameters.AddWithValue("@book_id", selectedID);
                        int result = cmd.ExecuteNonQuery();

                        if (result == 1)
                        {
                            MessageBox.Show("Book successfully deleted.");
                            Clear();
                        }
                        // display updated books
                        displayBooks();
                    }
                }
                catch
                {
                    MessageBox.Show("Del error");
                }
            }
        }
        
        private void BtnBack_Click(object sender, RoutedEventArgs e)
        {
            AdminHome adminhome = new AdminHome();
            this.NavigationService.Navigate(adminhome);
        }
    }
}
