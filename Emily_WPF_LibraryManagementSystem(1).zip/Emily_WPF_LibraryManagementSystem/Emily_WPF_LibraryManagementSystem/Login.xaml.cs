﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Data;
using System.Windows.Documents;
using System.Windows.Input;
using System.Windows.Media;
using System.Windows.Media.Imaging;
using System.Windows.Navigation;
using System.Windows.Shapes;
using System.Data.OleDb;
using System.Data;

namespace Emily_WPF_LibraryManagementSystem
{
    /// <summary>
    /// Interaction logic for Login.xaml
    /// </summary>
    public partial class Login : Page
    {
        public static string userid;
        public static string pass;
        public static string userName;
        OleDbConnection con;
        OleDbCommand cmd;

        public static string Userid
        {
            get
            {
                return userid;
            }
            set
            {
                userid = value;
            }
        }

        public Login()
        {
            InitializeComponent();
            txtName.Focus();
        }

        private void BtnRegister_Click(object sender, RoutedEventArgs e)
        {
            UserRegisteration register = new UserRegisteration();
            this.NavigationService.Navigate(register);
        }

        private void Page_Loaded(object sender, RoutedEventArgs e)
        {
            btnSubmit.Focus();
            con = new OleDbConnection();
            con.ConnectionString = @"Provider=Microsoft.Jet.OLEDB.4.0;Data Source=Library.mdb";
        }

        private void BtnSubmit_Click(object sender, RoutedEventArgs e)
        {
            if (con.State == ConnectionState.Closed)
            {
                con.Open();
            }

            userName = txtName.Text;
            pass = txtPassword.Password;
            cmd = new OleDbCommand("Select * from Login where UserName = @userName and Password = @pass", con);
            cmd.Parameters.AddWithValue("@UserName", userName);
            cmd.Parameters.AddWithValue("@pass", pass);
            DataTable table = new DataTable();
            OleDbDataAdapter adapter = new OleDbDataAdapter(cmd);
            adapter.Fill(table);

            if (table.Rows.Count > 0)
            {
                userid = txtName.Text;
                pass = txtPassword.Password;
                for (int i = 0; i < table.Rows.Count; i++)
                {
                    if (Convert.ToString(table.Rows[i][3]) == "1")
                    {
                        userid = table.Rows[i][0].ToString();
                        AdminHome adminHome = new AdminHome();
                        this.NavigationService.Navigate(adminHome);
                    }
                    else
                    {
                        userid = table.Rows[i][0].ToString();
                        UserMain userMain = new UserMain();
                        this.NavigationService.Navigate(userMain);
                    }
                }
            }
            else
            {
                MessageBox.Show("Name or Password is invalid!");
            }
        }
    }
}
