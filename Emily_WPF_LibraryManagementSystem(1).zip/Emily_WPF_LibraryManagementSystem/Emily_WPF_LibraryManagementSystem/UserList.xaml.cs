﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Data;
using System.Windows.Documents;
using System.Windows.Input;
using System.Windows.Media;
using System.Windows.Media.Imaging;
using System.Windows.Navigation;
using System.Windows.Shapes;
using System.Data.OleDb;
using System.Data;

namespace Emily_WPF_LibraryManagementSystem
{
    /// <summary>
    /// Interaction logic for UserList.xaml
    /// </summary>
    public partial class UserList : Page
    {
        bool state = true;
        OleDbConnection con;
        OleDbCommand cmd;
        string name = "";
        int id = 0;
        int permission = 0;

        public UserList()
        {
            InitializeComponent();
           
        }

        private void Page_Loaded(object sender, RoutedEventArgs e)
        {
            con = new OleDbConnection();
            con.ConnectionString = @"Provider=Microsoft.Jet.OLEDB.4.0;Data Source=Library.mdb";
            con.Open();

            cmd = new OleDbCommand("Select * from Login order by UserID ASC", con);
            OleDbDataAdapter adapter = new OleDbDataAdapter(cmd);
            DataTable table = new DataTable();
            adapter.Fill(table);
            
            dataGrid.ItemsSource = table.AsDataView();
        }

        private void BtnSearch_Click(object sender, RoutedEventArgs e)
        {
            OleDbCommand cmd = new OleDbCommand("SELECT * FROM Login WHERE UserName LIKE '" + txtSearch.Text + "%'", con);
            OleDbDataAdapter adapterSearch = new OleDbDataAdapter(cmd);
            DataTable table = new DataTable();
            adapterSearch.Fill(table);
            dataGrid.ItemsSource = table.DefaultView;
        }

        private void BtnBack_Click(object sender, RoutedEventArgs e)
        {
            AdminHome adminHome = new AdminHome();
            this.NavigationService.Navigate(adminHome);
        }

        private void DataGrid_SelectionChanged(object sender, SelectionChangedEventArgs e)
        {
            DataGrid gd = (DataGrid)sender;
            DataRowView row_selected = gd.SelectedItem as DataRowView;

            if (row_selected != null)
            {
                txtID.Text = row_selected["UserID"].ToString();
                txtName.Text = row_selected["UserName"].ToString();
                txtPermission.Text = row_selected["Permission"].ToString();
            }

            id = Convert.ToInt32(txtID.Text);
            name = txtName.Text;
            permission = Convert .ToInt32(txtPermission.Text);

        }
        
        private void BtnUpdate_Click(object sender, RoutedEventArgs e)
        {
            if (con.State == ConnectionState.Closed)
            {
                con.Open();
            }

            if (state == true)
            {
                try
                {
                    cmd = new OleDbCommand("update Login set UserName = '" + txtName.Text + "', Permission = '" + txtPermission.Text + "' where UserID=id ", con);
                    cmd.Parameters.AddWithValue("@UserID", id);
                    cmd.Parameters.AddWithValue("@UserName", name  );
                    cmd.Parameters.AddWithValue("@Permission", permission );
                    cmd.ExecuteNonQuery();
                    int result = cmd.ExecuteNonQuery();

                    if (result == 1)
                    {
                        MessageBox.Show("Successfully updated.");
                        Clear();
                    }
                    
                }
                catch(Exception ex)
                {
                    MessageBox.Show(ex.Message);
                }
            }
        }

        private void Clear()
        {
            txtID.Text = "";
            txtName.Text = "";
            txtPermission.Text = "";
        }

        private void BtnDelete_Click(object sender, RoutedEventArgs e)
        {
            if (con.State == ConnectionState.Closed)
                con.Open();

            OleDbCommand cmd = new OleDbCommand("delete * from Login where UserID =@id", con);
            cmd.Parameters.AddWithValue("@UserID", id);
            cmd.ExecuteNonQuery();
            MessageBox.Show("Successfully Deleted");
            Clear();
        }

        private void BtnCancel_Click(object sender, RoutedEventArgs e)
        {
            Clear();
        }
    }
}
