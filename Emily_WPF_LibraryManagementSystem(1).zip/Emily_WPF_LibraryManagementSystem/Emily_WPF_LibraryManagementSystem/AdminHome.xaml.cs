﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Data;
using System.Windows.Documents;
using System.Windows.Input;
using System.Windows.Media;
using System.Windows.Media.Imaging;
using System.Windows.Navigation;
using System.Windows.Shapes;
using System.Data.OleDb;
using System.Data;

namespace Emily_WPF_LibraryManagementSystem
{
    /// <summary>
    /// Interaction logic for AdminHome.xaml
    /// </summary>
    public partial class AdminHome : Page
    {
        public string userid;
        public int id;
        public string pass;
        OleDbConnection con;
        OleDbCommand cmd;
        string queryString;
        DataTable table = new DataTable();

        public AdminHome()
        {
            InitializeComponent();
        }

        private void Page_Loaded(object sender, RoutedEventArgs e)
        {
            con = new OleDbConnection();
            con.ConnectionString = @"Provider=Microsoft.Jet.OLEDB.4.0;Data Source=Library.mdb";
            con.Open();
            displayBooks();
        }

        private void displayBooks()
        {
            try
            {
                OleDbCommand cmd = new OleDbCommand("Select * from BookList order by BookID ASC", con);
                OleDbDataAdapter adapter = new OleDbDataAdapter(cmd);
                DataTable table = new DataTable();
                adapter.Fill(table);

                dataGrid.ItemsSource = table.DefaultView;
            }
            catch
            {
                return;
            }
        }

        private void BtnLogout_Click(object sender, RoutedEventArgs e)
        {
            Login login = new Login();
            this.NavigationService.Navigate(login);
            Login.userid = "";
        }

        private void BtnSearch_Click(object sender, RoutedEventArgs e)
        {
            if (con.State == ConnectionState.Closed)
                con.Open();

            OleDbCommand cmd = new OleDbCommand("SELECT * FROM BookList WHERE Title LIKE '" + txtSearch.Text + "%' OR Author LIKE '" + txtSearch.Text + "%'", con);
            OleDbDataAdapter adapterSearch = new OleDbDataAdapter(cmd);
            DataTable table = new DataTable();
            adapterSearch.Fill(table);
            dataGrid.ItemsSource = table.DefaultView;
        }

        private void BtnUser_Click(object sender, RoutedEventArgs e)
        {
            UserList user = new UserList();
            this.NavigationService.Navigate(user);
        }

        private void BtnEdit_Click(object sender, RoutedEventArgs e)
        {
            EditBooks update = new EditBooks();
            this.NavigationService.Navigate(update);
        }

        private void BtnInsert_Click(object sender, RoutedEventArgs e)
        {
            InsertNewBook insertBook = new InsertNewBook();
            this.NavigationService.Navigate(insertBook);
        }

        private void BtnReturn_Click(object sender, RoutedEventArgs e)
        {
            Return returnBook = new Return();
            this.NavigationService.Navigate(returnBook);
        }

        private void BtnIssue_Click(object sender, RoutedEventArgs e)
        {
            Issue issue = new Issue();
            this.NavigationService.Navigate(issue);
        }
    }
}
